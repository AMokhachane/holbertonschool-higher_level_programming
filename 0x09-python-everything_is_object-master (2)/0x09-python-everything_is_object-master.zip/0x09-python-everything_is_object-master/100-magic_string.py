#!/usr/bin/python3
def magic_string(H=[]):
    H += ["BestSchool"]
    return (", ".join(H))
