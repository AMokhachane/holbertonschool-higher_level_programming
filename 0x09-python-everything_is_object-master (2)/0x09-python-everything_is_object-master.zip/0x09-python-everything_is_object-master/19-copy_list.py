#!/usr/bin/python3
def copy_list(lista):
    return lista.copy()
