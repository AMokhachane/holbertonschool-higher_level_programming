# 0x09-python-everything_is_object
Python
